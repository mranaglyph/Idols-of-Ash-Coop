extends Node3D

@onready var _name_label: Label3D = $NameLabel

func set_player_name(p_name: String) -> void:
	if is_node_ready():
		_name_label.text = p_name
	else:
		await ready
		_name_label.text = p_name

func update_transform(pos: Vector3, rot: Vector3, p_name: String) -> void:
	global_position = pos
	global_rotation = rot
	if _name_label.text != p_name:
		_name_label.text = p_name
