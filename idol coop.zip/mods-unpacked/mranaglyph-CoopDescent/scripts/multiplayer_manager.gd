extends Node

const MOD_DIR := "res://mods-unpacked/mranaglyph-CoopDescent/"
const MAX_MEMBERS := 4
const SYNC_HZ := 20.0

var local_player: CharacterBody3D = null
var local_name := "Player"
var session_password := ""
var is_host := false
var lobby_ui: Node = null

var _lobby_id: int = 0
var _my_steam_id: int = 0
var _host_steam_id: int = 0
var _peers: Dictionary = {}  # steam_id (int) -> RemotePlayer node
var _sync_accum := 0.0
var _scan_accum := 0.0

func _ready() -> void:
	_my_steam_id = Steam.getSteamID()

	Steam.lobby_created.connect(_on_lobby_created)
	Steam.lobby_joined.connect(_on_lobby_joined)
	Steam.lobby_match_list.connect(_on_lobby_match_list)
	Steam.lobby_chat_update.connect(_on_lobby_chat_update)
	Steam.network_messages_session_request.connect(_on_session_request)

	get_tree().node_added.connect(_on_node_added)
	get_tree().node_removed.connect(_on_node_removed)

	var lobby_scene: PackedScene = load(MOD_DIR + "scenes/lobby.tscn")
	lobby_ui = lobby_scene.instantiate()
	get_tree().root.call_deferred("add_child", lobby_ui)

func _process(delta: float) -> void:
	Steam.run_callbacks()
	_poll_messages()

	if _lobby_id == 0:
		return

	if local_player == null:
		_scan_accum += delta
		if _scan_accum >= 2.0:
			_scan_accum = 0.0
			_scan_for_player()
		return

	_sync_accum += delta
	if _sync_accum >= 1.0 / SYNC_HZ:
		_sync_accum = 0.0
		_broadcast_position()

# --- player detection ---

func _on_node_added(node: Node) -> void:
	if (node.name == "Climber" or node.name == "Player") and node is CharacterBody3D:
		await get_tree().process_frame
		local_player = node as CharacterBody3D
		print("[CoopDescent] Local player detected: %s" % node.name)

func _scan_for_player() -> void:
	if local_player != null:
		return
	var found := _find_player_in(get_tree().root)
	if found:
		local_player = found
		print("[CoopDescent] Local player found via scan")

func _find_player_in(node: Node) -> CharacterBody3D:
	if (node.name == "Climber" or node.name == "Player") and node is CharacterBody3D:
		return node as CharacterBody3D
	for child in node.get_children():
		var result := _find_player_in(child)
		if result:
			return result
	return null

func _on_node_removed(node: Node) -> void:
	if node == local_player:
		local_player = null

# --- public API called by lobby UI ---

func host(player_name: String, pwd: String) -> void:
	local_name = player_name
	session_password = pwd
	is_host = true
	_host_steam_id = _my_steam_id
	Steam.createLobby(Steam.LOBBY_TYPE_PUBLIC, MAX_MEMBERS)
	print("[CoopDescent] Creating lobby...")

func join(player_name: String, pwd: String) -> void:
	local_name = player_name
	session_password = pwd
	is_host = false
	Steam.addRequestLobbyListStringFilter("coop_game", "CoopDescent", Steam.LOBBY_COMPARISON_EQUAL)
	Steam.addRequestLobbyListStringFilter("coop_pwd", str(pwd.hash()), Steam.LOBBY_COMPARISON_EQUAL)
	Steam.requestLobbyList()
	print("[CoopDescent] Searching for lobby...")

func disconnect_session() -> void:
	if _lobby_id != 0:
		Steam.leaveLobby(_lobby_id)
		_lobby_id = 0
	for id in _peers.keys():
		_remove_remote_player(id)
	_peers.clear()
	_host_steam_id = 0
	is_host = false
	print("[CoopDescent] Disconnected")

# --- Steam lobby signals ---

func _on_lobby_created(connect: int, lobby_id: int) -> void:
	if lobby_id == 0:
		is_host = false
		_set_status("Failed to create lobby (error %d)." % connect)
		_set_connected(false)
		return
	_lobby_id = lobby_id
	Steam.setLobbyData(lobby_id, "coop_game", "CoopDescent")
	Steam.setLobbyData(lobby_id, "coop_pwd", str(session_password.hash()))
	_set_status("Hosting — lobby open.\nShare the password with friends.\nWaiting for players...")
	print("[CoopDescent] Lobby created: %d" % lobby_id)

func _on_lobby_match_list(lobbies: Array) -> void:
	if lobbies.is_empty():
		_set_status("No lobby found.\nCheck the password, or ask the host\nto create a lobby first.")
		_set_connected(false)
		return
	var target: int = lobbies[0]
	Steam.joinLobby(target)
	print("[CoopDescent] Found lobby %d, joining..." % target)

func _on_lobby_joined(lobby_id: int, _permissions: int, _locked: bool, response: int) -> void:
	if response != Steam.CHAT_ROOM_ENTER_RESPONSE_SUCCESS:
		_set_status("Failed to join lobby (response %d)." % response)
		_set_connected(false)
		_lobby_id = 0
		return
	_lobby_id = lobby_id
	_host_steam_id = Steam.getLobbyOwner(lobby_id)
	var count := Steam.getNumLobbyMembers(lobby_id)
	for i in range(count):
		var member := Steam.getLobbyMemberByIndex(lobby_id, i)
		if member != _my_steam_id:
			Steam.acceptSessionWithUser(member)
	_set_status("Connected!\nPlayers: %d / %d\nWaiting for others to load in..." % [count, MAX_MEMBERS])
	_scan_for_player()
	print("[CoopDescent] Joined lobby %d (%d members)" % [lobby_id, count])

func _on_lobby_chat_update(lobby_id: int, changed_id: int, _making_change_id: int, chat_state: int) -> void:
	if lobby_id != _lobby_id:
		return
	var count := Steam.getNumLobbyMembers(_lobby_id)
	if chat_state & Steam.CHAT_MEMBER_STATE_CHANGE_ENTERED:
		Steam.acceptSessionWithUser(changed_id)
		_set_status("Player joined!\nPlayers: %d / %d" % [count, MAX_MEMBERS])
		print("[CoopDescent] Peer entered: %d" % changed_id)
	else:
		_remove_remote_player(changed_id)
		if lobby_ui and lobby_ui.has_method("on_peer_disconnected"):
			lobby_ui.on_peer_disconnected(changed_id)
		if not is_host and changed_id == _host_steam_id:
			_on_host_left()
		else:
			_set_status("Player left.\nPlayers: %d / %d" % [count, MAX_MEMBERS])
		print("[CoopDescent] Peer left: %d" % changed_id)

func _on_host_left() -> void:
	Steam.leaveLobby(_lobby_id)
	_lobby_id = 0
	for id in _peers.keys():
		_remove_remote_player(id)
	_peers.clear()
	_set_status("Host left the session.")
	_set_connected(false)
	print("[CoopDescent] Host left — session ended")

# --- Steam networking ---

func _on_session_request(remote_steam_id: int) -> void:
	Steam.acceptSessionWithUser(remote_steam_id)

func _poll_messages() -> void:
	if _lobby_id == 0:
		return
	var msgs: Array = Steam.receiveMessagesOnChannel(0, 32)
	for msg in msgs:
		var sender_id: int = msg.get("identity", 0)
		var data: PackedByteArray = msg.get("payload", PackedByteArray())
		if sender_id != 0 and data.size() > 0:
			_handle_message(sender_id, data)

func _handle_message(sender_id: int, data: PackedByteArray) -> void:
	var payload = bytes_to_var(data)
	if typeof(payload) != TYPE_DICTIONARY:
		return
	if payload.get("type", "") == "pos":
		var pos: Vector3 = payload.get("pos", Vector3.ZERO)
		var rot: Vector3 = payload.get("rot", Vector3.ZERO)
		var pname: String = payload.get("name", "Player")
		if sender_id not in _peers or not is_instance_valid(_peers.get(sender_id)):
			_spawn_remote_player(sender_id, pname)
		if is_instance_valid(_peers.get(sender_id)):
			_peers[sender_id].update_transform(pos, rot, pname)

func _broadcast_position() -> void:
	if _lobby_id == 0 or local_player == null:
		return
	var data := var_to_bytes({
		"type": "pos",
		"pos": local_player.global_position,
		"rot": local_player.global_rotation,
		"name": local_name
	})
	var count := Steam.getNumLobbyMembers(_lobby_id)
	for i in range(count):
		var member := Steam.getLobbyMemberByIndex(_lobby_id, i)
		if member != _my_steam_id:
			Steam.sendMessageToUser(member, data, Steam.NETWORKING_SEND_UNRELIABLE, 0)

# --- helpers ---

func _set_status(msg: String) -> void:
	if lobby_ui and lobby_ui.has_method("set_status"):
		lobby_ui.set_status(msg)

func _set_connected(connected: bool) -> void:
	if lobby_ui and lobby_ui.has_method("set_connected"):
		lobby_ui.set_connected(connected)

# --- remote player management ---

func _spawn_remote_player(peer_id: int, player_name: String) -> void:
	if get_tree().current_scene == null:
		return
	var scene: PackedScene = load(MOD_DIR + "scenes/remote_player.tscn")
	var rp: Node = scene.instantiate()
	rp.name = "RemotePlayer_%d" % peer_id
	get_tree().current_scene.add_child(rp)
	rp.set_player_name(player_name)
	_peers[peer_id] = rp
	print("[CoopDescent] Spawned remote player for peer %d" % peer_id)

func _remove_remote_player(peer_id: int) -> void:
	if peer_id in _peers:
		if is_instance_valid(_peers[peer_id]):
			_peers[peer_id].queue_free()
		_peers.erase(peer_id)
