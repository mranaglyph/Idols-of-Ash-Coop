extends Node

const LOG_NAME := "mranaglyph-CoopDescent"
const MOD_DIR := "res://mods-unpacked/mranaglyph-CoopDescent/"

func _ready() -> void:
	var manager: Node = load(MOD_DIR + "scripts/multiplayer_manager.gd").new()
	manager.name = "MultiplayerManager"
	get_tree().root.call_deferred("add_child", manager)
	ModLoaderLog.info("CoopDescent loaded", LOG_NAME)
